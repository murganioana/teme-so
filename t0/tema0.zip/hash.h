/* Tudorica Constantin-Alexandru, 333CA */
#ifndef HASH_H_
#define HASH_H_

unsigned int hash(const char *str, unsigned int hash_length);

#endif

