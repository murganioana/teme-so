Tudorica Constantin-Alexandru, 333CA,  Tema 1 Linux
	
	Am implementat tema folosind scheletul de cod de la voi completand
TODO-urile din cod. Pentru implementarea operatorului de pipe am fork-uit
procesul curent in 2 procese ce vor calcula partea stanga si partea dreapta a
pipe-ului.