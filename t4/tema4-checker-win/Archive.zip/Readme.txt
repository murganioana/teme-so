Tudorica Constantin-Alexandru, 333CA
	Pe windows a fost simplu, am luat versiunea de linux si am schimbat cateva
functii si asta a fost tot. Am folosit tot semafoare fara nume ca si pe linux
pentru sincronizare, cred ca la fel de usor era si cu event-uri, dar nu am mai
schimbat, am zis ca daca si pe linux sunt semafoare sa fie si pe windows tot la
fel.
	Cam atat. Spor la corectat teme.
	